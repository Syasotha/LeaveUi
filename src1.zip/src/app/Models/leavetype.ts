export class Leavetype {
    id:number;
	leaveType:String;
	allocationDays:number;
}
