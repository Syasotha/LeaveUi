export class Department {
        id:number;
        departmentName:String;
}
