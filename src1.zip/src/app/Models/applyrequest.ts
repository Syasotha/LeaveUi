export class Applyrequest {
}
