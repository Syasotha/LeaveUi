export class Status {
    id:Number;
	status:String;
}
