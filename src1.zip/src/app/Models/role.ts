export class Role {
    id:Number;
	roleName:String;
}
