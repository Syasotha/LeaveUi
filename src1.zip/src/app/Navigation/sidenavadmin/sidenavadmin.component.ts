import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sidenavadmin',
  templateUrl: './sidenavadmin.component.html',
  styleUrls: ['./sidenavadmin.component.css']
})
export class SidenavadminComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
