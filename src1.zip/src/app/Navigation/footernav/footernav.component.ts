import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footernav',
  templateUrl: './footernav.component.html',
  styleUrls: ['./footernav.component.css']
})
export class FooternavComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
