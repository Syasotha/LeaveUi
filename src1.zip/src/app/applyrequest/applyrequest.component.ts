import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-applyrequest',
  templateUrl: './applyrequest.component.html',
  styleUrls: ['./applyrequest.component.css']
})
export class ApplyrequestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
